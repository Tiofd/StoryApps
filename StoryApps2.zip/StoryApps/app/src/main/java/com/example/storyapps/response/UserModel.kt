package com.example.storyapps.response

data class UserModel(
    val name: String,
    val token: String,
    val isLogin: Boolean
)
